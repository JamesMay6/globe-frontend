const StatsMenu = () => {
  return (
    <div className="stats-menu">
      <h2>Your Stats</h2>
      <p>Clicks: ...</p>
    </div>
  );
};

export default StatsMenu;