const LeaderboardMenu = () => {
  return (
    <div className="leaderboard-menu">
      <h2>Leaderboard</h2>
      <p>Top Players...</p>
    </div>
  );
};

export default LeaderboardMenu;